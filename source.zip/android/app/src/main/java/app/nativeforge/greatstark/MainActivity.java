package app.nativeforge.greatstark;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
