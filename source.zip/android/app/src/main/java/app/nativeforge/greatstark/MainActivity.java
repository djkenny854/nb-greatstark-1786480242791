package app.nativeforge.greatstark;

import android.os.Bundle;
import androidx.core.view.WindowCompat;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // True native edge-to-edge. super.onCreate(...) must run first so Capacitor creates the WebView.
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
    }
}
