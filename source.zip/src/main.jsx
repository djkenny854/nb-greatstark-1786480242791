import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { HashRouter } from 'react-router-dom'
import { store } from './app/store.js'
import { Provider } from 'react-redux'
import "./capacitor/edgeToEdge";
import "./capacitor/edgeToEdgeSpacer";
import "./capacitor/safe-area.css";

createRoot(document.getElementById('root')).render(
    <HashRouter>
            <Provider store={store}>
                <App />
            </Provider>
    </HashRouter>,
)